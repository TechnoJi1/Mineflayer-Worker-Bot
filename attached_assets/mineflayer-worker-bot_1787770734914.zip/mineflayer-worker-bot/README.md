# Mineflayer Worker Bot — Standalone (Railway-ready)

This is your bot's actual logic (`src/`), repackaged as a **plain npm project** with
no pnpm workspace, no unrelated scaffolding (React mockup, API server, DB schema)
that Replit generated around it. This is the only folder you need to deploy.

## 1. Set up your config

```bash
cp settings.example.json settings.json
```

Then edit `settings.json` and fill in at minimum:
- `server.host` / `server.port` / `server.version`
- `bot.username` (and `server.auth`: `"offline"`, `"mojang"`, or `"microsoft"`)
- `access.commandUsernames` — your in-game username(s) allowed to send `!mine`, `!farm`, etc.
- `home.coordinates` and `home.chest` — must point at a **real chest** you've placed
- Enable/disable and tune each module under `modules.*` as you like

The bot will refuse to start if `settings.json` is missing, `bot.username` is empty,
or `access.commandUsernames` is empty — this is intentional, it's a safety check
baked into `src/config.ts`.

## 2. Install and test locally (optional but recommended)

```bash
npm install
npm start
```

Watch the console for `[Bot] spawned and ready`. Try `!status` in-game from a
whitelisted username to confirm the chat command loop works before deploying.

## 3. Deploy to Railway

1. Push this folder's contents to a GitHub repo (root of the repo = this folder,
   i.e. `package.json` should be at the repo root, not nested).
2. In Railway: **New Project → Deploy from GitHub repo**.
3. Railway will auto-detect Node.js via `package.json`. No special build command
   needed — default `npm install` + `npm start` (from your `package.json` scripts)
   works out of the box since this is no longer a pnpm workspace.
4. **Important:** `settings.json` is in `.gitignore` by default for safety (it can
   contain a password/webhook). You have two options:
   - Add environment-specific handling to read secrets from env vars instead, or
   - Simply remove `settings.json` from `.gitignore` and commit it if the repo is
     **private** and you're comfortable with that.
5. Set the health check: Railway will detect the Express server started by
   `src/server.ts` (default port 3000, or `$PORT` if Railway sets it — the code
   already respects `process.env.PORT` indirectly via `settings.health.port`,
   double check this matches Railway's expected port).

## What changed from your old bot

- No more `periodic-rejoin` / canned `chat-messages` — those were AFK-only tricks.
  This bot does *real* work (mine/farm/fight/deposit) so it doesn't need to fake activity.
- State machine replaces simple reconnect-loop: `IDLE → WORKING/COMBAT/FLEEING → IDLE`,
  with death/respawn handled explicitly.
- Config is stricter — it validates on startup rather than failing silently later.

## Chat commands (from a whitelisted username)

| Command | Effect |
|---|---|
| `!mine <block_name>` or `!mine` | Queue a mining task (specific ore or default target list) |
| `!farm` | Queue a farming pass over the configured region |
| `!guard` | Stay near home, auto-fight anything hostile in range |
| `!stop` | Clear the task queue, stop current task, return to idle |
| `!status` | Bot replies with current state, task, HP, inventory fullness |
